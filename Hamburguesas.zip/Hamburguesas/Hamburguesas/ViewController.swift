//
//  ViewController.swift
//  Hamburguesas
//
//  Created by Vicente Contreras López on 30/08/16.
//  Copyright © 2016 Vicente Contreras López. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var etiquetaPais: UILabel!
    @IBOutlet weak var etiquetaHamburguesa: UILabel!
    
    
    let paises = ColeccinDePaises()
    let hamburguesas = ColeccionDeHamburguesas()
    let color = Colores()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func CambiaPais_Hamburguesa() {
        etiquetaPais.text = paises.obtenPais()
        etiquetaHamburguesa.text = hamburguesas.obtenHamburguesa()
        let colorAleatorio = color.regresoColorAleatorio()
        view.backgroundColor = colorAleatorio
        view.tintColor = colorAleatorio
    }
}

