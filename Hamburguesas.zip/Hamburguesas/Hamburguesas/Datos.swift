//
//  Datos.swift
//  Hamburguesas
//
//  Created by Vicente Contreras López on 30/08/16.
//  Copyright © 2016 Vicente Contreras López. All rights reserved.
//hamburguesas

import Foundation
import UIKit

class ColeccinDePaises {
    let paises = ["Mexico", "Inglaterra", "Estados Unidos", "Jamaica", "Japon", "Guatemala", "China", "Irlanda", "Canada", "Espania", "Francia", "Brasil", "Peru", "Argentina", "Italia", "Finlandia", "Alemania","Rusia","Cuba","Rumania"]
    
    func obtenPais() -> String {
        let posicion = Int(arc4random()) % paises.count
        return paises[posicion]
    }
    
}

class ColeccionDeHamburguesas {
    let hamburguesas = ["Hawaiana", "Al carbon", "Con queso", "Doble Carne", "Queso Fundido", "Vegetariana", "Normal", "Grande", "Chica", "Especial", "Con tocino", "Con Chile", "Pan Horneado", "Con pepinillos", "Sin queso", "Pan con Ajonjoli", "Con papas","De pollo","De pescado","Con jamon"]
    
    func obtenHamburguesa() -> String {
        let posicion = Int(arc4random()) % hamburguesas.count
        return hamburguesas[posicion]
    }
}

struct Colores {
    let colores = [ UIColor(red:210/255.0, green: 90/255.0, blue: 45/255.0, alpha: 1),
                    
                    UIColor(red:40/255.0, green: 170/255.0, blue: 45/255.0, alpha: 1),
                    
                    UIColor(red:3/255.0, green: 180/255.0, blue: 90/255.0, alpha: 1),
                    
                    UIColor(red:210/255.0, green: 190/255.0, blue: 5/255.0, alpha: 1),
                    
                    UIColor(red:120/255.0, green: 120/255.0, blue: 50/255.0, alpha: 1),
                    
                    UIColor(red:130/255.0, green: 80/255.0, blue: 90/255.0, alpha: 1),
                    
                    UIColor(red:130/255.0, green: 130/255.0, blue: 130/255.0, alpha: 1),
                    
                    UIColor(red:3/255.0, green: 50/255.0, blue: 90/255.0, alpha: 1)]
    
    func regresoColorAleatorio() -> UIColor {
        let posicion = Int (arc4random()) % colores.count
        return colores[posicion]
    }
}
